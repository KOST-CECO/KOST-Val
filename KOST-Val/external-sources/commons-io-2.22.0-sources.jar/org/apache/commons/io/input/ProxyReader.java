/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.io.input;

import static org.apache.commons.io.IOUtils.EOF;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.CharBuffer;

import org.apache.commons.io.IOUtils;

/**
 * A reader proxy which delegates to the wrapped reader.
 * <p>
 * It is an alternative base class to FilterReader
 * to increase reusability, because FilterReader changes the
 * methods being called, such as read(char[]) to read(char[], int, int).
 * </p>
 */
public abstract class ProxyReader extends FilterReader {

    /**
     * Constructs a new ProxyReader.
     *
     * @param delegate  the Reader to delegate to.
     */
    public ProxyReader(final Reader delegate) {
        // the delegate is stored in a protected superclass variable named 'in'
        super(delegate);
    }

    /**
     * Invoked by the read methods after the proxied call has returned
     * successfully. The number of chars returned to the caller (or -1 if
     * the end of stream was reached) is given as an argument.
     * <p>
     * Subclasses can override this method to add common post-processing
     * functionality without having to override all the read methods.
     * The default implementation does nothing.
     * </p>
     * <p>
     * Note this method is <em>not</em> called from {@link #skip(long)} or
     * {@link #reset()}. You need to explicitly override those methods if
     * you want to add post-processing steps also to them.
     * </p>
     *
     * @param n number of chars read, or -1 if the end of stream was reached.
     * @throws IOException if the post-processing fails.
     * @since 2.0
     */
    @SuppressWarnings("unused") // Possibly thrown from subclasses.
    protected void afterRead(final int n) throws IOException {
        // noop
    }

    /**
     * Invoked by the read methods before the call is proxied. The number
     * of chars that the caller wanted to read (1 for the {@link #read()}
     * method, buffer length for {@link #read(char[])}, etc.) is given as
     * an argument.
     * <p>
     * Subclasses can override this method to add common pre-processing
     * functionality without having to override all the read methods.
     * The default implementation does nothing.
     * </p>
     * <p>
     * Note this method is <em>not</em> called from {@link #skip(long)} or
     * {@link #reset()}. You need to explicitly override those methods if
     * you want to add pre-processing steps also to them.
     * </p>
     *
     * @param n number of chars that the caller asked to be read.
     * @throws IOException if the pre-processing fails.
     * @since 2.0
     */
    @SuppressWarnings("unused") // Possibly thrown from subclasses.
    protected void beforeRead(final int n) throws IOException {
        // noop
    }

    /**
     * Invokes the delegate's {@code close()} method.
     *
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public void close() throws IOException {
        try {
            in.close();
        } catch (final IOException e) {
            handleIOException(e);
        }
    }

    /**
     * Handle any IOExceptions thrown.
     * <p>
     * This method provides a point to implement custom exception
     * handling. The default behavior is to re-throw the exception.
     * </p>
     *
     * @param e The IOException thrown.
     * @throws IOException if an I/O error occurs.
     * @since 2.0
     */
    protected void handleIOException(final IOException e) throws IOException {
        throw e;
    }

    /**
     * Invokes the delegate's {@code mark(int)} method.
     *
     * @param readAheadLimit read ahead limit.
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public synchronized void mark(final int readAheadLimit) throws IOException {
        try {
            in.mark(readAheadLimit);
        } catch (final IOException e) {
            handleIOException(e);
        }
    }

    /**
     * Invokes the delegate's {@code markSupported()} method.
     *
     * @return true if mark is supported, otherwise false.
     */
    @Override
    public boolean markSupported() {
        return in.markSupported();
    }

    /**
     * Invokes the delegate's {@code read()} method.
     *
     * @return the character read or -1 if the end of stream.
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public int read() throws IOException {
        try {
            beforeRead(1);
            final int c = in.read();
            afterRead(c != EOF ? 1 : EOF);
            return c;
        } catch (final IOException e) {
            handleIOException(e);
            return EOF;
        }
    }

    /**
     * Invokes the delegate's {@code read(char[])} method.
     *
     * @param chr the buffer to read the characters into.
     * @return the number of characters read or -1 if the end of stream.
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public int read(final char[] chr) throws IOException {
        try {
            beforeRead(IOUtils.length(chr));
            final int n = in.read(chr);
            afterRead(n);
            return n;
        } catch (final IOException e) {
            handleIOException(e);
            return EOF;
        }
    }

    /**
     * Invokes the delegate's {@code read(char[], int, int)} method.
     *
     * @param chr the buffer to read the characters into.
     * @param st The start offset.
     * @param len The number of bytes to read.
     * @return the number of characters read or -1 if the end of stream.
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public int read(final char[] chr, final int st, final int len) throws IOException {
        try {
            beforeRead(len);
            final int n = in.read(chr, st, len);
            afterRead(n);
            return n;
        } catch (final IOException e) {
            handleIOException(e);
            return EOF;
        }
    }

    /**
     * Invokes the delegate's {@code read(CharBuffer)} method.
     *
     * @param target the char buffer to read the characters into.
     * @return the number of characters read or -1 if the end of stream.
     * @throws IOException if an I/O error occurs.
     * @since 2.0
     */
    @Override
    public int read(final CharBuffer target) throws IOException {
        try {
            beforeRead(IOUtils.length(target));
            final int n = in.read(target);
            afterRead(n);
            return n;
        } catch (final IOException e) {
            handleIOException(e);
            return EOF;
        }
    }

    /**
     * Invokes the delegate's {@code ready()} method.
     *
     * @return true if the stream is ready to be read.
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public boolean ready() throws IOException {
        try {
            return in.ready();
        } catch (final IOException e) {
            handleIOException(e);
            return false;
        }
    }

    /**
     * Invokes the delegate's {@code reset()} method.
     *
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public synchronized void reset() throws IOException {
        try {
            in.reset();
        } catch (final IOException e) {
            handleIOException(e);
        }
    }

    /**
     * Sets the underlying reader.
     * <p>
     * Use with caution.
     * </p>
     *
     * @param in The input stream to set in {@code java.io.Reader#in}.
     * @return {@code this} instance.
     * @since 2.22.0
     */
    public ProxyReader setReference(final Reader in) {
        this.in = in;
        return this;
    }


    /**
     * Invokes the delegate's {@code skip(long)} method.
     *
     * @param ln the number of bytes to skip.
     * @return the number of bytes to skipped or EOF if the end of stream.
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public long skip(final long ln) throws IOException {
        try {
            return in.skip(ln);
        } catch (final IOException e) {
            handleIOException(e);
            return 0;
        }
    }

    /**
     * Unwraps this instance by returning the underlying {@link Reader}.
     * <p>
     * Use with caution.
     * </p>
     *
     * @return the underlying {@link Reader}.
     * @since 2.22.0
     */
    public Reader unwrap() {
        return in;
    }

}
